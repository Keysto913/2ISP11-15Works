package com.example.kursachganiushkin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_window);
    }
    public void toKatalog(View view) {
        Intent intent = new Intent(Login.this, Katalog.class);
        startActivity(intent);
    }
}
