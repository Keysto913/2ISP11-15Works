package com.example.kursachganiushkin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Tovar extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tovar_window);
    }

    public void toBin(View view) {
        Intent intent = new Intent(Tovar.this,Bin.class);
        startActivity(intent);
    }
}
