package com.example.kursachganiushkin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Katalog extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.katalog_window);
    }

    public void toTovar(View view) {
        Intent intent = new Intent(Katalog.this, Tovar.class);
        startActivity(intent);
    }
}
