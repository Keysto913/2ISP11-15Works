package com.example.kursachganiushkin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Bin extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bin_window);
    }

    public void toPurchase(View view) {
        Intent intent = new Intent(Bin.this, Purchase.class);
        startActivity(intent);
    }
}
